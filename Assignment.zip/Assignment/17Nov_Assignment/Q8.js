function q8() {
    console.clear();

    function demo(a, b) {
        "use strict";
        let total = a + b;
        console.log(total);
    }

    demo(5, 10);
}
