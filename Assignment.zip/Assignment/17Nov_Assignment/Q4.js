"use strict";

function q4() {
    console.clear();
    function showMessage() {
        let greeting = "Welcome";
        console.log(greeting);
    }
    showMessage();
}
